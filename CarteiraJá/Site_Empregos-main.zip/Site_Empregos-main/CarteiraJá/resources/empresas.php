<!DOCTYPE html>
<html lang="pt-br">
<head>
     <meta charset="UTF-8"> 
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Empresas - CarteiraJá</title>
   <link rel="stylesheet" href="style_empres.css">
   <link rel="icon" type="image/png" href="resources/icon.svg">

</head>
<body>
    <header>

        <div class="logo"><a href="../index.html">CarteiraJá</a></div>

        <nav>
              <ul class="nav_links">
                   <!-- <li><a href="#">FALE CONOSCO</a></li> -->
                   <li><a href="#">EMPRESAS</a></li>


              </ul>
        </nav>
    </header>
<!--        <div class="box">
            <form action="">
                <fieldset>
                    <legend><b>Autentique-se</b></legend>
                        <br><br>
                    <div class="inputBox">
                        <input type="text" name="cnpj" id="nome" class="inputUser" required onkeydown="bloquearEspaco(event)">
                        <label for="nome">CNPJ</label>
                    </div>
                    <div class="inputBox">
                        <input type="text" name="senha" id="sobrenome" class="inputUser" required onkeydown="bloquearEspaco(event)">
                        <label for="sobrenome">Senha</label>
                    </div>
                    <br><br><br>
                    <input type="submit" name="submit" id="submit" >
                </fieldset>
            </form>
        </div>
-->
